var firebaseConfig = {
  apiKey: "AIzaSyAQG25w_HBbcg0m5oeCN2ioD9tAOe-xgNg",
  authDomain: "ivyhacks2020-185c3.firebaseapp.com",
  databaseURL: "https://ivyhacks2020-185c3.firebaseio.com",
  projectId: "ivyhacks2020-185c3",
  storageBucket: "ivyhacks2020-185c3.appspot.com",
  messagingSenderId: "490237359530",
  appId: "1:490237359530:web:28e68e63651471baeda7d3",
  measurementId: "G-P9WMSHRT5P"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
// firebase.analytics();
const db = firebase.firestore();

// Add schools to dropdown
let selectSchool = document.getElementById("select-school");
db.collection("schools").get().then((querySnapshot) => {
  querySnapshot.forEach((doc) => {
    let school = document.createElement("option");
    school.value = doc.id;
    school.text = doc.data().name;
    selectSchool.add(school);
  });
});

// Add classes to dropdown
let schoolId = "Sr4v1oOa5lmrKNujaiFz";
let selectClass = document.getElementById("select-class");
document.getElementById("btn-school").onclick = function() {
  // Clear options in dropdown
  let length = selectClass.options.length;
  for (i = length - 1; i > 0; i--) {
    selectClass.options[i] = null;
  }

  schoolId = selectSchool.options[selectSchool.selectedIndex].value;
  console.log(schoolId);
  db.collection("schools").doc(schoolId).collection("classes").get().then((querySnapshot) => {
    querySnapshot.forEach((doc) => {
      let c = document.createElement("option");
      c.value = doc.id;
      c.text = doc.data().name;
      selectClass.add(c);
    });
  });
}

let classes = [];
document.getElementById("btn-class").onclick = function() {
  let confidence = parseInt(document.getElementById("input-conf").value, 10);
  if (confidence < 1) {confidence = 1;}
  else if (confidence > 10) {confidence = 10};
  let c = {
    "id": selectClass.options[selectClass.selectedIndex].value,
    "conf": confidence,
  };
  classes.push(c);

  document.getElementById("p-class").innerHTML += selectClass.options[selectClass.selectedIndex].text + " (" + c.conf + "), ";

  document.getElementById("input-conf").value = 0;
}

document.getElementById("btn-profile").onclick = function() {
  let uname = document.getElementById("input-user").value;
  // console.log(uname, classes);

  // create new user document
  let userId;
  db.collection("users").add({
    username: uname,
    schoolid: schoolId
  }).then(function(docRef) {
    userId = docRef.id;
    console.log("Document written with ID: ", userId);
    for(let c of classes) {
      // Add the class to user
      db.collection("users").doc(userId).collection("classes").add({
        classid: c.id,
        conf: c.conf
      }).then(function(docRef) {
        // Add user to class' "ungrouped" group
        let added = false;
        db.collection("schools").doc(schoolId).collection("classes").doc(c.id).collection("groups").get().then((querySnapshot) => {
          querySnapshot.forEach((doc) => {
            if (doc.data().name == "ungrouped") {
              // Add group to user
              db.collection("users").doc(userId).collection("classes").doc(docRef.id).collection("groups").add({
                groupid: doc.id
              });
              // Add user to group
              db.collection("schools").doc(schoolId).collection("classes").doc(c.id).collection("groups").doc(doc.id).collection("members").add({
                userid: userId
              });
              added = true;
            }
          });
        });
        if (!added) {
          // If "ungrouped" doesn't exist, create it
          db.collection("schools").doc(schoolId).collection("classes").doc(c.id).collection("groups").add({
            name: "ungrouped",
            stay: false
          });
          .then(function(docRef) {
            db.collection("schools").doc(schoolId).collection("classes").doc(c.id).collection("groups").doc(docRef.id).collection("members").add({
              userid: userId
            });
          })
          .catch(function(error) {
            console.error("Error adding document: ", error);
          });
        }
      });
    }
    document.getElementById("input-user").value = "";
    document.getElementById("p-class").value = "";
  }).catch(function(error) {
    console.error("Error adding document: ", error);
  });  
}