var firebaseConfig = {
  apiKey: "AIzaSyAQG25w_HBbcg0m5oeCN2ioD9tAOe-xgNg",
  authDomain: "ivyhacks2020-185c3.firebaseapp.com",
  databaseURL: "https://ivyhacks2020-185c3.firebaseio.com",
  projectId: "ivyhacks2020-185c3",
  storageBucket: "ivyhacks2020-185c3.appspot.com",
  messagingSenderId: "490237359530",
  appId: "1:490237359530:web:28e68e63651471baeda7d3",
  measurementId: "G-P9WMSHRT5P"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
// firebase.analytics();
const db = firebase.firestore();

//group class contains an array of users, pointer to course num, and stay boolean
//allgroups is an array of all sorted groups
//ungrouped is a group object where the stay boolean is always false and all students start there
//user is a class with a name (string), courses (array of courseinfo objects)
//couseinfo class contains a pointer to the course and a group number

// For each class in each school, mixes students in groups with stay = false into groups of 3 to 5.
let schoolsRef = db.collection("schools");
var noGroup = new Object(); // userid's of members of all stay = false groups in class
let courseNums = []; // list of courses for which to mix groups
function remixAllGroups() {
  noGroup = new Object();
  schoolsRef.get().then((querySnapshot) => {
    querySnapshot.forEach((doc) => {
      let schoolId = doc.id;
      let classesRef = schoolsRef.doc(schoolId).collection("classes");
      classesRef.get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
          let classId = doc.id;
          courseNums.push(classId);
          // console.log("classId: " + classId);
          let groupsRef = classesRef.doc(classId).collection("groups");
          // noGroup = []; // didn't work :(
          groupsRef.get().then((querySnapshot) => {
            querySnapshot.forEach((doc) => {
              let groupId = doc.id;
              // console.log("groupId: " + groupId);
              let membersRef = groupsRef.doc(groupId).collection("members");
              if (doc.data().stay == false) {
                membersRef.get().then((querySnapshot) => {
                  querySnapshot.forEach((doc) => {
                    // Add userid to list
                    let userId = doc.data().userid;
                    db.collection("users").doc(userId).collection("classes").get().then((querySnapshot) => {
                      querySnapshot.forEach((doc) => {
                        if (doc.data().classid == classId) {
                          let userCI = new userCourseInfo(classId, doc.data().conf);
                          // console.log("pushed " + userId + " to " + classId);
                          if (noGroup[userId] == undefined) {
                            noGroup[userId] = [];
                          }
                          noGroup[userId].push(userCI)
                        }
                      });
                    });
                    // Remove group from user
                    /*db.collection("users").doc(userId).collection("classes").doc(classId).collection("groups").get().then((querySnapshot) => {
                      querySnapshot.forEach((doc) => {
                        if (doc.data().groupid == groupId) {
                          db.collection("users").doc(userId).collection("classes").doc(classId).collection("groups").doc(doc.id).delete().then(function() {
                            console.log("Document successfully deleted!");
                          }).catch(function(error) {
                            console.error("Error removing document: ", error);
                          });
                        }
                      })
                    });*/
                    // Delete user from members WILL THIS WORK?
                    /*membersRef.doc(doc.id).delete().then(function() {
                      console.log("Document successfully deleted!");
                    }).catch(function(error) {
                      console.error("Error removing document: ", error);
                    });*/
                  });
                });
              }
              /*if (doc.data().name != "ungrouped") {
                // Remove group IDK IF THIS IS LEGAL
                groupsRef.doc(groupId).delete().then(function() {
                  console.log("Document successfully deleted!");
                }).catch(function(error) {
                  console.error("Error removing document: ", error);
                });
              }*/
            });
          });
        });
      });
      // Make new groups of 5
      console.log(doc.data().name, noGroup);
      console.log(Object.keys(JSON.parse(JSON.stringify(noGroup))).length === 0);
      let needGroupUsers = [];
      for (let key in noGroup) {
        let newUser = new user(key, noGroup[key]);
        needGroupUsers.push(newUser);
      }
      console.log(needGroupUsers);
      // let newGroups = setupGroups(noGroup);
    });
  });
}

//start of algo stuff (need to adapt to firebase)

/*let allusers = [];
//ungrouped is index 0 of allgroupsinclass
let allgroupsincourse = [];*/

class user {
  constructor(username, userCourseInformation) {
    this.name = username; // userid
    this.courses = userCourseInformation;
  }
}

class group {
  constructor(usersInGroup, courseNumber, stayBool) {
    this.users = usersInGroup;
    this.courseNum = courseNumber;
    this.stay = stayBool;
  }
}

class userCourseInfo {
  constructor(courseNumber, confidenceLevel/*,groupNumber*/) {
    this.courseNum = courseNumber; // courseid
    // groupNum = groupNumber;
    this.conlev = confidenceLevel;
  }
}

/*function initializeUsersIntoClass(courseNum) {
  //change first line
  let allusersincourse = allusers.filter(u =>(u.courses.filter(c=>c.courseNum===courseNum)).length!==0);
  allgroupsincourse.push(new group(allusersincourse, courseNum, false));
}*/

function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min)) + min;
}

function setupGroups(needNewGroupUsers, courseNum) {
  let newGroups;
  /*let newGroups = allgroupsincourse.filter(group => group.stay);
  let changeGroups = allgroupsincourse.filter(group => (group.stay === false));
  function reduceHelper(acc, cur) {
    for(let i = 0; i < cur.length; ++i) {
      acc.push(cur[i]);
    }
    return acc;
  }*/
  /*let needNewGroupUsers = changeGroups.reduce(reduceHelper,[]);*/
  function sorter(a,b){
    let aConLev;
    for(let i = 0; i<a.courses.length; ++i) {
      if(a.courses[i].courseNum===courseNum) {
        aConLev = a.courses[i].conlev;
      }
    }

    let bConLev;
    for(let i = 0; i<b.courses.length; ++i) {
      if(b.courses[i].courseNum===courseNum) {
        bConLev = b.courses[i].conlev;
      }
    }

    return a.courses.conlev-b.courses.conlev;
  }
  needNewGroupUsers = needNewGroupUsers.sort(sorter);

  for(let i = 0; needNewGroupUsers.length>10; ++i) {
    let newGroup = new group([], courseNum, false);
    for(let j = 0; j < 5; ++j) {
      let middle = Math.floor(needNewGroupUsers.length/2);
      if(j%2===0) {
        let rand = randomInt(0,middle);
        newGroup.users.push(needNewGroupUsers[rand]);
        needNewGroupUsers.splice(rand,1);
      }
      else if(j%2===0) {
        let rand = randomInt(middle,needNewGroupUsers.length);
        newGroup.users.push(needNewGroupUsers[rand]);
        needNewGroupUsers.splice(rand,1);
      }
    }
    newGroups.push(newGroup);
  }
  let remgrp1 = new group([], courseNum, false);
  let remgrp2 = new group([], courseNum, false);
  for(let i = 0; i < needNewGroupUsers.length; ++i) {
    if(i%2===0) {
      remgrp1.users.push(needNewGroupUsers[i]);
    }
    else {
      remgrp2.users.push(needNewGroupUsers[i]);
    }
  }
  return newGroups;
}

remixAllGroups();